package es.curso.java.introduccion.arrays;

public class EjemplosArraysInt {

	public static void main(String[] args) {
		
		
		int [][] num = {{1,2,3} , {4,5,6}};
		System.out.print(num);
		
		
		
	}
	
}
