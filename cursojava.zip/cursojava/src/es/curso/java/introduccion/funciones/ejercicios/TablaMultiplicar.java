package es.curso.java.introduccion.funciones.ejercicios;

import java.util.Scanner;

public class TablaMultiplicar {

	public static void main (String [] args){
		
		
	}
	
	static void pintaTablaMultiplicar (int num) {		 
		for (int i = 0 ; i < 11 ; i++ ) {
			System.out.println(num+" * " + i + " = " + (num * i));
					}
		
	}
	

	
}
