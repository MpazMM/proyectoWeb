package es.curso.java.introduccion.funciones;

public class Funciones2 {
	
	public static void metodo3() {
		System.out.println("metodo3 clase2");
	}
	public static void metodo4() {
		System.out.println("metodo4 clase2");
	}

	
}
