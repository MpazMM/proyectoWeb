package excepciones.ejercicios.temperatura;

public class CoffeCup {

	private int temperature;

	public CoffeCup(int temperature) {
		super();
		this.temperature = temperature;
	}

	
	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}


	public int getTemperature() {
		return temperature;
	}
	
	
}
