package excepciones.ejercicios.temperatura;

public class TemperatureException extends Exception {

}
