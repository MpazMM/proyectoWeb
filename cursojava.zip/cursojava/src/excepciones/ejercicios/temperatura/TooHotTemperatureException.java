package excepciones.ejercicios.temperatura;

public class TooHotTemperatureException extends TemperatureException {

}
