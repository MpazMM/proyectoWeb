package excepciones.ejercicios.temperatura;

public class TooColdTemperatureException extends TemperatureException{

}
